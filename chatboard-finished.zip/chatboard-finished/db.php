<?php 

define("USER","root");
define("PASS","jackass9");
define("HOST","localhost");
define("DB","chatboard");

$connection = mysqli_connect(HOST,USER,PASS,DB);

if(!$connection){
	echo "Failure " . mysqli_connect_error();
}

 ?>
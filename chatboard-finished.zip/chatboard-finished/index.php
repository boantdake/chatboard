<?php 

include('db.php');

$query = "SELECT * FROM posts ORDER BY id DESC LIMIT 10";

$post = mysqli_query($connection, $query);




 ?>


<!DOCTYPE html>
<html  lang="en">
		<head>
			<meta charset="UTF-8">
			<title>ChatBoard</title>
 			
			<!-- bootstrap 3.3.7 cdn css -->
			<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
			<!-- stylesheet -->
			<link rel="stylesheet" type="text/css" href="css/custom.css">
		</head>

			<body>
				<div class="container">
				<header><h1>Star Wars ChatBoard</h1></header>
					<div id="board">
						<!-- 	this is where the posts will go -->
						<ul class="list-group clearfix">
							<?php 
								while($rows = mysqli_fetch_assoc($post)) :	
				
					echo	"<li class='list-group-item'>" . $rows['date'] . "--" . $rows['name'] . " wrote <br>" . $rows['post'] . " </li> ";
					
					endwhile;
					
							 ?>
						</ul>	
					</div>

							

				



						
					
				
				<footer>
				<!-- post input section -->
					<div class="row">
						<div class="col-md-6 col-md-offset-3">
							<form action="" class="form-group">
								<input type="text" class="form-control" id="name" placeholder="Your Name">
								<textarea id="post" class="form-control" placeholder="Message..."></textarea>
								<button class="btn btn-success pull-right" id="sendit" data-key='sent'>Post</button>
							</form>
						</div>
					</div>
					<audio src="sounds/good.wav"></audio>
				</footer>

</div>




			    <!-- Jquery CDN -->
	 			<script src="https://code.jquery.com/jquery-3.2.1.js" integrity="sha256-DZAnKJ/6XZ9si04Hgrsxu/8s717jcIzLy3oi35EouyE=" crossorigin="anonymous"></script>
	 			<!-- bootstrap 3.3.7 cdn js -->
				<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
				<!-- ckeditor 4.7.1 CDN -->
				<script src="js/ckeditor/ckeditor.js"></script>
				<!-- javascript custom -->
				<script src="js/js1.js" type="text/javascript"></script>
			</body>

</html>
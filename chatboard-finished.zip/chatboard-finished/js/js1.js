function getDate(){
	let here = new Date();
	var date = here.getUTCMonth() + ":" + here.getUTCDay() + " " + here.getHours() + ":" + here.getMinutes();
	
	return date.toString();

}

$(document).ready(function(){
	$('list-group-item').css('height','auto');
	CKEDITOR.replace('post',//this is necessary to include Ckeditor instead of our text area. now in order to use the image uploading ability you need to alias the ckeditor in your httpd.conf file in xampp or your apache.conf file in LAMP like this Alias /ckeditor C:/xampp/htdocs/ajaxshoutbox/js/ckeditor
	{

        on :
        {
            instanceReady : function()
            {

                // Output paragraphs as <p>Text</p>.
                this.dataProcessor.writer.setRules( 'p',
                    {
                        indent : false,
                        breakBeforeOpen : true,
                        breakAfterOpen : false, breakBeforeClose : false,
                        breakAfterClose : true
                    });
            }
        }
    });
	$('#sendit').click(function(){
		$('audio')[0].play();
		var name = $('#name').val();
		var post = CKEDITOR.instances['post'].getData();//we would normally use $('#shout').val() to grab the value and send it but we are using ckeditor so we have to use its selector in order to grab the data.
		var replaced = post.trim();
		
		var date = getDate(); //getDate();///we will create this function
		var stuff = 'name=' + name + '&replaced=' + replaced + '&date=' + date;
		console.log(stuff);//this logged html tags <p>joking right</p> just remember that when you go to parse it through to the li tags
		//validation check on name and message, if its empty it sends an alert, if not it will send the form via AJAX and the POST method to shoutbox.php
		if(name == '' || replaced == ''){
			alert('Please fill out the form completely');
		}else{
			$.ajax({
				cache:false,
				type: "POST",
				url:'./process.php',//this is to go back two complete files to the root and then access shoutbox.php.
				data: stuff,//this is the variable we made up there called data string.
				success: function(stuff){//if the call is successful we will redirect back to the start
					$('#board ul').prepend(stuff);//this will add list items
					//location.reload();
				}
				// failed: function(){//if it fails we will show a failed output abov the shout input location(not added will add later.)
				// 	$('.uhoh').show();
				// }

			});//close out ajax
		}//close out else
		

		return false;

	});//close click event

});